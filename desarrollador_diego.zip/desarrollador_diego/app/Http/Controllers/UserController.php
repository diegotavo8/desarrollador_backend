<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserCreateRequest;
use App\Http\Requests\UserUpdateRequest;
use Illuminate\Http\Request;

class UserController extends Controller
{
    //
    public function index(){
    	$users = \App\User::paginate(5);
		return view('users.index', compact('users'));
    }

    public function create(){
		return view('users.create');
	}

	public function store(UserCreateRequest $request){
		if($request->ajax()){
			\App\User::create([
				'first_name'	=> $request['txt_first_name'],
				'last_name'		=> $request['txt_last_name'],
				'email'			=> $request['txt_email'],
				'password'		=> bcrypt($request['txt_password'])
			]);
			
			return response()->json([
				"200" => "Usuario creado con exito"
			]);
		}
	}

    public function edit($id){
		$user = \App\User::find($id);
		return view('users.edit', compact('user'));
	}

    public function update(UserUpdateRequest $request, $id){
		if($request->ajax()){
			$user = \App\User::find($id);
			
			//Verifica si hubo cambio de password
			$password = null;
			if (strcmp($request['txt_password'], $user->password) !== 0) {
				$password = bcrypt($request['txt_password']);
			}
			else{
				$password = $user->password;
			}

			$user->update([
				'first_name'	=> $request['txt_first_name'],
				'last_name'		=> $request['txt_last_name'],
				'email'			=> $request['txt_email'],
				'password'		=> $password,
			]);

			return response()->json([
				"200" => "Usuario modificado con exito"
			]);
		}
	}

    public function destroy($id){
		\App\User::destroy($id);
		return response()->json([
			"200" => "Usuario eliminado con exito"
		]);
	}
}

<?php

namespace App\Http\Controllers;

use Auth;
use Session;
use Redirect;
use App\Http\Requests\LoginRequest;

use Illuminate\Http\Request;

class LoginController extends Controller
{

    //
    public function index(){
    	return view('index');
    }

    public function store(LoginRequest $request){
    	//Verifico que sea AJAX
    	if($request->ajax()){
    		//Verifico la autenticacion de usuario
	    	if(Auth::attempt(['email'=>$request['txt_email'], 'password'=>$request['txt_password']])){
				//return Redirect::to('admin');
				return response()->json(['200'=>'admin']);
			}
			else{
				//return response('Usuario o contraseña incorrecto', 401)->header('Content-Type', 'text/plain');
				return response()->json(['401'=>'Usuario o contraseña incorrecto']);
			}
		}
    }

    public function admin(){
    	return view('inicio.admin');	
    }

    public function logout(){
		Auth::logout();
		return Redirect::to('/');
	}
}

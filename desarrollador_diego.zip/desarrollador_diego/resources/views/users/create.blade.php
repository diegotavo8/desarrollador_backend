<head>
	<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.css') }}">
	<script type="text/javascript" src="{{ asset('js/jquery-3.1.1.min.js') }}"></script>
	<script>
		$(function(){
			$("#btn_aceptar").click(function(){
				var datos= {
					'txt_first_name': $("#txt_first_name").val(),
					'txt_last_name'	: $("#txt_last_name").val(),
					'txt_email'		: $("#txt_email").val(),
					'txt_password'	: $("#txt_password").val()
				};
				$.ajax({
					url: "{{ route('users.store') }}",
					dataType: 'json',
					type: "POST",
					data: datos,
					cache: false,
					timeout: 10000,
					headers: {
						'X-CSRF-TOKEN': $('input[name="_token"]').attr('value')
					},
					statusCode: {
						201: function() {
							$("#respuesta").html("La respuesta no contiene cuerpo");
						},
						404: function() {
							$("#status").html("Página no encontrada");
						},
						500: function(xhr) {
							if(window.console) console.log(xhr.responseText);
						}
					},
					beforeSend:function (){
						$("#respuesta").html("Procesando...");
					},
					success: function(respuesta){
						if(respuesta['200']){
							$("#respuesta").html(respuesta['200']);
						}
					},
					error: function(respuesta){
						$("#respuesta").html("<ul>");
						$.each(respuesta.responseJSON.errors, function( key, value ) {
					  		$("#respuesta").append("<li>"+ value +"</li>");
						});
						$("#respuesta").append("</ul>");
					}
				});
			});
		});
	</script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
	<div class="collapse navbar-collapse" id="navbarNav">
		<ul class="navbar-nav">
			<li class="nav-item">
				<a class="nav-link" href="{{ url('admin') }}">Inicio</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="{{ url('users') }}">Listar usuarios</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="{{ url('users/create') }}">Crear Usuarios</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="{{ url('logout') }}">Cerra sesión</a>
			</li>
		</ul>
	</div>
</nav>
<div>
	<h5>Crear Usuario</h5>
	<form>
		@csrf
		<div class="form-group row">
			<label class="col-4 col-form-label">Nombre: *</label>
			<div class="col-8">
				<input type="text" class="form-control" id="txt_first_name">
			</div>
		</div>
		<div class="form-group row">
			<label class="col-4 col-form-label">Apellido: *</label>
			<div class="col-8">
				<input type="text" class="form-control" id="txt_last_name">
			</div>
		</div>
		<div class="form-group row">
			<label class="col-4 col-form-label">Correo: *</label>
			<div class="col-8">
				<input type="text" class="form-control" id="txt_email">
			</div>
		</div>
		<div class="form-group row">
			<label class="col-4 col-form-label">Contraseña: *</label>
			<div class="col-8">
				<input type="password" class="form-control" id="txt_password">
			</div>
		</div>
		<input type="button" class="btn btn-secondary" value="Ingresar" id="btn_aceptar">
	</form>
	<div id="respuesta"></div>
<div>
</body>
</html>
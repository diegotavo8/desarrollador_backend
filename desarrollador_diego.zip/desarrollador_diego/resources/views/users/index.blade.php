<html>
<head>
	<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.css') }}">
	<script type="text/javascript" src="{{ asset('js/jquery-3.1.1.min.js') }}"></script>
	<script type="text/javascript">
function eliminar(url){
	var r = confirm("Está seguro de elminar este registro!");
	if (r == true) {
		$.ajax({
			url: url,
			dataType: 'json',
			type: "DELETE",
			cache: false,
			timeout: 10000,
			headers: {
				'X-CSRF-TOKEN': $('input[name="_token"]').attr('value')
			},
			statusCode: {
				404: function() {
					$("#respuesta").html("Página no encontrada");
				},
				500: function(xhr) {
					if(window.console) console.log(xhr.responseText);
				}
			},
			beforeSend:function (){
				$("#respuesta").html("Procesando...");
			},
			success: function(respuesta){
				if(respuesta['401']){
					$("#respuesta").html(respuesta['401']);
				}
				if(respuesta['200']){
					$("#respuesta").html(respuesta['200']);
				}
			},
			error: function(respuesta){
				$("#respuesta").html("<ul>");
				$.each(respuesta.responseJSON.errors, function( key, value ) {
			  		$("#respuesta").append("<li>"+ value +"</li>");
				});
				$("#respuesta").append("</ul>");
			}
		});
	}
}
	</script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
	<div class="collapse navbar-collapse" id="navbarNav">
		<ul class="navbar-nav">
			<li class="nav-item">
				<a class="nav-link" href="{{ url('admin') }}">Inicio</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="{{ url('users') }}">Listar usuarios</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="{{ url('users/create') }}">Crear Usuarios</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="{{ url('logout') }}">Cerra sesión</a>
			</li>
		</ul>
	</div>
</nav>
	<table class="table">
		<tr>
			<td>Nombre</td>
			<td>Apellido</td>
			<td>Correo</td>
			<td>Fecha creado</td>
			<td>Fecha modificado</td>
			<td>Acciones</td>
		</tr>
		@foreach($users as $user)
		<tr>
			<td>{!! $user->first_name !!}</td>
			<td>{!! $user->last_name !!}</td>
			<td>{!! $user->email !!}</td>
			<td>{!! $user->created_at !!}</td>
			<td>{!! $user->updates_at !!}</td>
			<td><a href="{{ route('users.edit', $user->id) }}">Editar</a>
			<input type="hidden" id="hid_id{{ $user->id }}" value="{{ route('users.destroy', $user->id) }}">
			<input type="button" class="btn btn-danger" value="Eliminar" onclick="eliminar($('#hid_id{{ $user->id }}').val())">
			</td>
		</tr>
		@endforeach
	</table>
	@csrf
	<div id="respuesta"></div>
</body>
</html>
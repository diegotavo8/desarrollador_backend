<html>
<head>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>">
	<script type="text/javascript" src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
	<div class="collapse navbar-collapse" id="navbarNav">
		<ul class="navbar-nav">
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(url('admin')); ?>">Inicio</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(url('users')); ?>">Listar usuarios</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(url('users/create')); ?>">Crear Usuarios</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(url('logout')); ?>">Cerra sesión</a>
			</li>
		</ul>
	</div>
</nav>

	Has iniciado session como <?php echo Auth::user()->first_name; ?> <?php echo Auth::user()->last_name; ?>

	
</body>
</html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>">
	<script type="text/javascript" src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>
	<script type="text/javascript">
function eliminar(url){
	var r = confirm("Está seguro de elminar este registro!");
	if (r == true) {
		$.ajax({
			url: url,
			dataType: 'json',
			type: "DELETE",
			cache: false,
			timeout: 10000,
			headers: {
				'X-CSRF-TOKEN': $('input[name="_token"]').attr('value')
			},
			statusCode: {
				404: function() {
					$("#respuesta").html("Página no encontrada");
				},
				500: function(xhr) {
					if(window.console) console.log(xhr.responseText);
				}
			},
			beforeSend:function (){
				$("#respuesta").html("Procesando...");
			},
			success: function(respuesta){
				if(respuesta['401']){
					$("#respuesta").html(respuesta['401']);
				}
				if(respuesta['200']){
					$("#respuesta").html(respuesta['200']);
				}
			},
			error: function(respuesta){
				$("#respuesta").html("<ul>");
				$.each(respuesta.responseJSON.errors, function( key, value ) {
			  		$("#respuesta").append("<li>"+ value +"</li>");
				});
				$("#respuesta").append("</ul>");
			}
		});
	}
}
	</script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
	<div class="collapse navbar-collapse" id="navbarNav">
		<ul class="navbar-nav">
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(url('admin')); ?>">Inicio</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(url('users')); ?>">Listar usuarios</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(url('users/create')); ?>">Crear Usuarios</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(url('logout')); ?>">Cerra sesión</a>
			</li>
		</ul>
	</div>
</nav>
	<table class="table">
		<tr>
			<td>Nombre</td>
			<td>Apellido</td>
			<td>Correo</td>
			<td>Fecha creado</td>
			<td>Fecha modificado</td>
			<td>Acciones</td>
		</tr>
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo $user->first_name; ?></td>
			<td><?php echo $user->last_name; ?></td>
			<td><?php echo $user->email; ?></td>
			<td><?php echo $user->created_at; ?></td>
			<td><?php echo $user->updates_at; ?></td>
			<td><a href="<?php echo e(route('users.edit', $user->id)); ?>">Editar</a>
			<input type="hidden" id="hid_id<?php echo e($user->id); ?>" value="<?php echo e(route('users.destroy', $user->id)); ?>">
			<input type="button" class="btn btn-danger" value="Eliminar" onclick="eliminar($('#hid_id<?php echo e($user->id); ?>').val())">
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<?php echo csrf_field(); ?>
	<div id="respuesta"></div>
</body>
</html>
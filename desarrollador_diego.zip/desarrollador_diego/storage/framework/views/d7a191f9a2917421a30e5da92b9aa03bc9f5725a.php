<html>
<head></head>
<body>
	
	Este es el módulo de administrador
	<a href="<?php echo e(url('logout')); ?>">Cerra sesión</a>
</body>
</html>
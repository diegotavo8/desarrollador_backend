<?php if(Browser::browserFamily() == "Chrome" || Browser::browserFamily() == "Firefox" || Browser::browserFamily() == "Opera"): ?>
	<p>La API no se puede ejecutar en este navegador. Por favor ingrese a un navegador no convencional</p>
<?php else: ?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>">
		<script type="text/javascript" src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>
		<script>
			$(function(){
				$("#btn_aceptar").click(function(){
					$.ajax({
						url: "<?php echo e(route('login.store')); ?>",
						dataType: 'json',
						type: "POST",
						data: {"txt_email" : $("#txt_email").val(), 'txt_password' : $("#txt_password").val()},
						cache: false,
						timeout: 10000,
						headers: {
							'X-CSRF-TOKEN': $('input[name="_token"]').attr('value')
						},
						statusCode: {
							404: function() {
								$("#respuesta").html("Página no encontrada");
							},
							500: function(xhr) {
								if(window.console) console.log(xhr.responseText);
							}
						},
						beforeSend:function (){
							$("#respuesta").html("Procesando...");
						},
						success: function(respuesta){
							if(respuesta['401']){
								$("#respuesta").html(respuesta['401']);
							}
							if(respuesta['200']){
								$(location).prop('href', "<?php echo e(url('admin')); ?>");
							}
						},
						error: function(respuesta){
							$("#respuesta").html("<ul>");
							$.each(respuesta.responseJSON.errors, function( key, value ) {
						  		$("#respuesta").append("<li>"+ value +"</li>");
							});
							$("#respuesta").append("</ul>");
						}
					});
				});
			});
		</script>
	</head>
	<body>
		<h3>Prueba desarrollador Backend</h3>
		<h5>Desarrollador: Diego Edisson Octavo</h5>
		<form>
			<?php echo csrf_field(); ?>
			<div class="form-group row">
				<label class="col-4 col-form-label">Correo: *</label>
				<div class="col-8">
					<input type="text" class="form-control" name="txt_email" id="txt_email">
				</div>
			</div>
			<div class="form-group row">
				<label class="col-4 col-form-label">Contraseña: *</label>
				<div class="col-8">
					<input type="password" class="form-control" name="txt_password" id="txt_password">
				</div>
			</div>
			<input type="button" class="btn btn-secondary" value="Ingresar" id="btn_aceptar">
		</form>
		<div id="respuesta"></div>
	</body>
</html>
<?php endif; ?>